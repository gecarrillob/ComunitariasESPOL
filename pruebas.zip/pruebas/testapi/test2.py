
import json
import requests
import requests.auth
apiuser = "apiuser"
apipass = "@piuser123"
url = 'https://api-misionalianza.it-doctux.com/api/user/'
headers = {'Authorization': 'Token b30ae636e25ad7e5451633ba8119100ed82eb250'}
r = requests.get(url, headers=headers)
print(r)

print("xXXXXXXXXXXXXXXXXX")
url2 = 'https://api-misionalianza.it-doctux.com/api/api-auth/login/'
apiuser2 = "sgdadmin"
apipass2 = "SGD@2020"


test_r = requests.get(url, auth=(apiuser2, apipass2))
print(test_r)
if(test_r):
    print("conectado")


    print(test_r.content)
    print(test_r.headers)
else:
    print("algo mal")
