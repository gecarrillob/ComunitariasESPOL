# Create your views here.

# views.py
from rest_framework import viewsets

from .serializers import HeroSerializer
from .models import Hero
#from rest_framework.permissions import IsAuthenticated  # <-- Here
from rest_framework.permissions import BasePermission, IsAuthenticated, SAFE_METHODS, IsAdminUser, AllowAny
class HeroViewSet(viewsets.ModelViewSet):
    permission_classes = (IsAuthenticated,)  
    queryset = Hero.objects.all().order_by('name')
    serializer_class = HeroSerializer
