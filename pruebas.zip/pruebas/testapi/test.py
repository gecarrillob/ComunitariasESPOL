
import json
import requests
import requests.auth
apiuser = "apiuser"
apipass = "@piuser123"
url = 'http://localhost:8000/heroes/'
headers = {'Authorization': 'Token b30ae636e25ad7e5451633ba8119100ed82eb250'}
r = requests.get(url, headers=headers)
print(r)
#url2 = 'https://api-misionalianza.it-doctux.com/api/api-auth/login/'
#apiuser2 = "sgdadmin"
#apipass2 = "SGD@2020"
url2 = 'http://localhost:8000/api-auth/login/'
apiuser2 = "testapi"
apipass2 = "Test@123"

test_r = requests.get(url2, auth=(apiuser2, apipass2))
print(test_r)
if(test_r):
    print("conectado")

    c = test_r.headers['Set-Cookie'].split(";")[0].split("=")
    token = c[1]
    print(token)
    print("XXXXXXXXXXXXXXXX")
    #print(test_r.content)
#looping through the iterator:
    for c in test_r.iter_lines():
      if "csrfmiddlewaretoken" in str(c):
          dato = str(c).split("value")
          print(dato[1])
       	  token = dato[1][2:-3]
          print(token)
          print(c)


    url = 'http://localhost:8000/heroes/'
    headers = {'Authorization': 'Token '+token}
    r = requests.get(url, headers=headers)
    print(r)
    #jtest = json.loads(test_r.content)
    #print(test_r.content)
    #print(test_r.headers)
else:
    print("algo mal")
